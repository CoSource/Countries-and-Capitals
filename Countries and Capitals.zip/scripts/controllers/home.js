angular.module('caps')
    .controller('HomeController', function ($window) {
        var vm = this;
    });